//
//  Student+CoreDataClass.swift
//  MyCoreDataApp
//
//  Created by Håkon Bogen on 11/10/2017,41.
//  Copyright © 2017 Håkon Bogen. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Student)
public class Student: NSManagedObject {

    
    convenience init?(attributes: [String : Any], managedObjectContext: NSManagedObjectContext) {
        
        guard let name = attributes["name"] as? String, let studentID = attributes["studentID"] as? Int else {
            return nil
        }
        
        let entity = NSEntityDescription.entity(forEntityName: "Student", in: managedObjectContext)!
        self.init(entity: entity, insertInto: managedObjectContext)
        
        self.name = name
        self.studentID = Int32(studentID)
        
        
    }
    
    
    
    
    
    
    
    
    
}
