//
//  Subject+CoreDataClass.swift
//  MyCoreDataApp
//
//  Created by Håkon Bogen on 11/10/2017,41.
//  Copyright © 2017 Håkon Bogen. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Subject)
public class Subject: NSManagedObject {

}
