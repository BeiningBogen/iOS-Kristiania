//
//  ViewController.swift
//  MyCoreDataApp
//
//  Created by Håkon Bogen on 11/10/2017,41.
//  Copyright © 2017 Håkon Bogen. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let delegate =  (UIApplication.shared.delegate as! AppDelegate)
        let context = delegate.persistentContainer.viewContext
        
        let studentDict = [ "name" : "Robert", "studentID" : 2342] as [String : Any]
        
        let student = Student.init(attributes: studentDict, managedObjectContext: context)
        
        delegate.saveContext()
        
        let fetchRequest = NSFetchRequest<Student>(entityName: "Student")
        let result = try! context.fetch(fetchRequest)
        
        
        for student in result {
            print(student.name)
        }
        
        context.delete(student!)
        
        delegate.saveContext()
        
        
        
        
    }


}

