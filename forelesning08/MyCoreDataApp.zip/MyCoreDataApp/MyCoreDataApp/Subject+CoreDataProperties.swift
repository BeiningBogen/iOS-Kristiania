//
//  Subject+CoreDataProperties.swift
//  MyCoreDataApp
//
//  Created by Håkon Bogen on 11/10/2017,41.
//  Copyright © 2017 Håkon Bogen. All rights reserved.
//
//

import Foundation
import CoreData


extension Subject {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Subject> {
        return NSFetchRequest<Subject>(entityName: "Subject")
    }

    @NSManaged public var name: String?
    @NSManaged public var subjectID: Int32
    @NSManaged public var student: Student?

}
