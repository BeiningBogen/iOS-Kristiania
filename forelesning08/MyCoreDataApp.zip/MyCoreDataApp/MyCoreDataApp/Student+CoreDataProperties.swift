//
//  Student+CoreDataProperties.swift
//  MyCoreDataApp
//
//  Created by Håkon Bogen on 11/10/2017,41.
//  Copyright © 2017 Håkon Bogen. All rights reserved.
//
//

import Foundation
import CoreData


extension Student {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Student> {
        return NSFetchRequest<Student>(entityName: "Student")
    }

    @NSManaged public var course: String?
    @NSManaged public var name: String
    @NSManaged public var studentID: Int32
    @NSManaged public var subjects: NSSet?
    
    
    

}

// MARK: Generated accessors for subjects
extension Student {

    @objc(addSubjectsObject:)
    @NSManaged public func addToSubjects(_ value: Subject)

    @objc(removeSubjectsObject:)
    @NSManaged public func removeFromSubjects(_ value: Subject)

    @objc(addSubjects:)
    @NSManaged public func addToSubjects(_ values: NSSet)

    @objc(removeSubjects:)
    @NSManaged public func removeFromSubjects(_ values: NSSet)

}
